
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

enum AppRoutes {
  onboarding,
  login,
  home,
  calendar,
  goals,
  journal,
  journalReflection,
  toolkit,
  recipes,



}



final goRouterProvider = Provider<GoRouter>((ref) {


  return GoRouter(
    initialLocation: '/',
    debugLogDiagnostics: false,
    redirect: (context, state) async {
      return null;
    },

    routes: [
      // Public routes (no authentication required)
      GoRoute(
        path: '/',
        name: AppRoutes.onboarding.name,
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: '/login',
        name: AppRoutes.login.name,
        builder: (context, state) => const LoginScreen(),
      ),

      // Protected routes (require authentication) with Shell
      ShellRoute(
        builder: (context, state, child) => MainScreen(child: child),
        routes: [
      
        ],
      ),

      // Additional protected routes (require authentication)
      GoRoute(
        path: '/journal-reflection',
        name: AppRoutes.journalReflection.name,
        builder: (context, state) => const JournalReflectionScreen(),
      ),
  
    ],
  );
});
